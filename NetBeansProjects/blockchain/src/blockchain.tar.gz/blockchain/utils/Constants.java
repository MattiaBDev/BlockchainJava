package blockchain.utils;

public class Constants {

    public static final int FRAME_WIDTH = 1000;
    public static final int FRAME_HEIGHT = 800;
    
    public static final String BACKGROUND = "/blockchain/gui/images/chain.jpg";
    public static final String ADD_BUTTON = "/blockchain/gui/images/addbutton.png";
}
