package blockchain.entities;

import java.util.Date;

public final class Block {

    public String hash;
    public String previousHash;
    private final long timeStamp; //as number of milliseconds since 1/1/1970.
    private int nonse;
    

    //Block Constructor.  
    public Block(String previousHash) { //Block's hash it's the timestamp where is applied an Hashing function 
        this.previousHash = previousHash;
        this.timeStamp = new Date().getTime();
        this.hash = calculateHash(); //Making sure we do this after we set the other values.
    }

    public String calculateHash() { //Function that implements SHA256 algorithm for hashing
        String calculatedhash = StringUtil.applySha256(this.previousHash
                + Long.toString(this.timeStamp)
                + Integer.toString(this.nonse)
        );
        return calculatedhash;
    }

    public void mineBlock(int difficulty) { //Block mining -> calculate hash while hashing isn't solved
        String target = new String(new char[difficulty]).replace('\0', '0'); //Create a string with difficulty * "0" 
        while (!this.hash.substring(0, difficulty).equals(target)) {
            this.nonse++;
            this.hash = calculateHash();
        }
        System.out.println("Block Mined!!! : " + this.hash);
    }
}
