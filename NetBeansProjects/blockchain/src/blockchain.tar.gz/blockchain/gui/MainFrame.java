package blockchain.gui;

import static blockchain.utils.Constants.*;
import javax.swing.JFrame;

public class MainFrame extends JFrame {

    MainPanel mainPanel;

    public MainFrame() {
        this.setName("Blockchain");
        this.setLayout(null);
        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setResizable(false);

        this.mainPanel = new MainPanel();
        this.getContentPane().add(this.mainPanel);
        this.mainPanel.setLocation(0, 0);
        this.mainPanel.setVisible(true);
    }
}
