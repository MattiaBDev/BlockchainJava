package blockchain.gui;

import blockchain.utils.Resources;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

public class HotArea extends Rectangle {

    private BufferedImage image;

    public HotArea(String path, int x, int y) {
        this.image = Resources.getImage(path);
        this.setBounds(x, y, this.image.getWidth(), this.image.getHeight());
    }

    public boolean isClicked(MouseEvent e) {
        return this.contains(e.getPoint());
    }

    public BufferedImage getImage() {
        return this.image;
    }

}
