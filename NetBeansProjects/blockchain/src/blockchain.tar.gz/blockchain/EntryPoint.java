package blockchain;

import blockchain.gui.MainFrame;

/**
 * @author Mattia Bapirasi Project: Blockchain - Java
 */
public class EntryPoint {

    public static void main(String[] args) {
        MainFrame mainFrame = new MainFrame();
        mainFrame.setVisible(true);
    }
    //Hyper ledger - consente di creare la blockchain
}
