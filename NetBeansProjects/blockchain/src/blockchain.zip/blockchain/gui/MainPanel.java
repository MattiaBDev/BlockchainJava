package blockchain.gui;

import blockchain.entities.Block;
import blockchain.entities.Blockchain;
import static blockchain.utils.Constants.*;
import blockchain.utils.Resources;
import static java.awt.Color.BLACK;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;

public class MainPanel extends JPanel {

    private Blockchain blockchain;
    private String lastHash;

    private HotArea newBlock;
    private Image background;

    public MainPanel() {
        this.setSize(FRAME_WIDTH, FRAME_HEIGHT);

        this.blockchain = new Blockchain();
        this.lastHash = "";
        this.newBlock = new HotArea(ADD_BUTTON, 620, 650);

        this.background = Resources.getImage(BACKGROUND);

        this.addMouseListener(new MouseAdapter() {

            public void mousePressed(MouseEvent e) {
                if (newBlock.isClicked(e)) {
                    Block transation = blockchain.addBlock(blockchain.size());
                    transation.mineBlock(blockchain.getDifficulty());
                    if (blockchain.isChainValid()) {
                        blockchain.removeBlock();
                    } else {
                        lastHash = transation.hash;
                    }
                    repaint();
                }
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(background, 0, 0, this);
        g.setFont(new Font("Arial", Font.BOLD, 12));
        g.setColor(BLACK);
        g.drawString("Last Hash code:", 670, 500);
        g.drawString(this.lastHash, 450, 550);
        g.drawImage(this.newBlock.getImage(), this.newBlock.getLocation().x, this.newBlock.getLocation().y, this);
    }
}
