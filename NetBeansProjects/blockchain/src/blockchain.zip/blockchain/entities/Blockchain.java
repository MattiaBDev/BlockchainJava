package blockchain.entities;

import java.util.ArrayList;

public final class Blockchain extends ArrayList<Block> {

    private int difficulty = 5;

    public Blockchain() {
        System.out.println("First block into blockchain.");
        this.addBlock(0);
    }

    /**
     *Meethod used to add a new block into the blockchain in posistion size().
     * @param numBlock
     * @return
     */
    public Block addBlock(int numBlock) {
        Block newBlock = new Block((numBlock + 1) + "");
        this.add(newBlock);
        return newBlock;
    }

    /**
     *
     */
    public void removeBlock() {
        Block lastBlock = this.get(this.size());
        this.remove(lastBlock);
    }

    public Boolean isChainValid() {
        Block currentBlock;
        Block previousBlock;
        String hashTarget = new String(new char[difficulty]).replace('\0', '0');

        //loop through blockchain to check hashes:
        for (int i = 1; i < this.size(); i++) {
            currentBlock = this.get(i);
            previousBlock = this.get(i - 1);
            //compare registered hash and calculated hash:
            if (!currentBlock.hash.equals(currentBlock.calculateHash())) {
                System.out.println("Current Hashes not equal");
                return false;
            }
            //compare previous hash and registered previous hash
            if (!previousBlock.hash.equals(currentBlock.previousHash)) {
                System.out.println("Previous Hashes not equal");
                return false;
            }
            //check if hash is solved
            if (!currentBlock.hash.substring(0, difficulty).equals(hashTarget)) {
                System.out.println("This block hasn't been mined");
                return false;
            }
        }
        return true;
    }

    public int getDifficulty() {
        return this.difficulty;
    }

    public void setDifficulty(int pDifficulty) {
        this.difficulty = pDifficulty;
    }

}
